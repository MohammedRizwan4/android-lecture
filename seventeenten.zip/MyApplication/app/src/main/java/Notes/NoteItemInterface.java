package Notes;

public interface NoteItemInterface {
    public void onItemClickListener(Notes notes);
    public void onItemLongClickListener(Notes notes);
}
