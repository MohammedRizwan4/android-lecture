package Notes;

import java.io.Serializable;

public class Notes implements Serializable {
    public static final String TABLE_NAME = "notes";
    public static final String c_notes_id = "note_id";
    public static final String c_note_title = "note_title";
    public static final String c_note_description = "note_description";
    public static final String SQL_CREATE_ENTITY = "create table " + TABLE_NAME + " (" + c_notes_id + " integer primary key, " + c_note_title + " text, " + c_note_description + " text)";
    public static final String SQL_DELETE_ENTITY = "drop table if exists " + TABLE_NAME;
    String noteTitle, noteDescription;

    public Notes() {

    }

    public Notes(String noteTitle, String noteDescription) {
        this.noteTitle = noteTitle;
        this.noteDescription = noteDescription;
    }

    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public String getNoteDescription() {
        return noteDescription;
    }

    public void setNoteDescription(String noteDescription) {
        this.noteDescription = noteDescription;
    }
}

