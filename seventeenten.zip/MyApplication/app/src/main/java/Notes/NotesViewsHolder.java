package Notes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class NotesViewsHolder extends RecyclerView.ViewHolder {
    TextView tvTitle, tvDescription;

    CardView cvItem;

    public NotesViewsHolder(@NonNull View itemView) {
        super(itemView);
        tvTitle = itemView.findViewById(R.id.tvTitle);
        tvDescription = itemView.findViewById(R.id.tvDescription);
        cvItem = itemView.findViewById(R.id.cvNoteItem);
    }
}
