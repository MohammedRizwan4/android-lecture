package Notes;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;

public class NotesDetailsFragment extends Fragment implements NoteItemInterface {
    ExtendedFloatingActionButton addNoteBtn;
    NotesActivity notesActivity;

    public NotesDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_notes_details, container, false);
        init(view);
        clickListener();

        RecyclerView recyclerView = view.findViewById(R.id.recycleView);
        NoteAdapter adapter = new NoteAdapter(this);
        recyclerView.setAdapter(adapter);

        adapter.setNotes(getNotes());
        return view;
    }

    public void init(View view){
        addNoteBtn = view.findViewById(R.id.addNote);
    }

    public void clickListener(){
        addNoteBtn.setOnClickListener(v -> {
            notesActivity.loadFragment(new NotesFragment());
        });
    }

    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
        notesActivity = (NotesActivity) getActivity();
    }

    private ArrayList<Notes> getNotes() {
        ArrayList<Notes> notes = new ArrayList<Notes>();
        notes.add(new Notes("TDD", "Test Driven Development"));
        notes.add(new Notes("Software Craftsmanship", "An Software Book"));
        notes.add(new Notes("BDD", "Behaviour Driven Development"));
        notes.add(new Notes("Clean code", "An Software Book"));
        return notes;
    }

    @Override
    public void onItemClickListener(Notes notes) {
        Toast.makeText(notesActivity, notes.getNoteTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemLongClickListener(Notes notes) {
        Toast.makeText(notesActivity, "I'm double click method", Toast.LENGTH_SHORT).show();
    }
}