package Notes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NotesViewsHolder> {

    private ArrayList<Notes> notes = new ArrayList<Notes>();
    private final NoteItemInterface noteItemInterface;

    NoteAdapter(NoteItemInterface noteItemInterface) {
        this.noteItemInterface = noteItemInterface;
    }

    @NonNull
    @Override
    public NotesViewsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.item_notes, parent, false);
        NotesViewsHolder viewsHolder = new NotesViewsHolder(v);
        return viewsHolder;
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }
    
    public void setNotes(ArrayList<Notes> notesList) {
        notes.clear();
        notes.addAll(notesList);
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull NotesViewsHolder holder, int position) {
        Notes note = notes.get(position);
        holder.tvTitle.setText(note.getNoteTitle());
        holder.tvDescription.setText(note.getNoteDescription());
        holder.cvItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteItemInterface.onItemClickListener(note);
            }
        });

        holder.cvItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                noteItemInterface.onItemLongClickListener(note);
                return false;
            }
        });
    }
}
