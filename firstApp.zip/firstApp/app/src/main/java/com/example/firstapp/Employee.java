package com.example.firstapp;

import java.io.Serializable;

public class Employee implements Serializable {
    String firstName, lastName, phoneNo, emailId, age, gender, address, qualification, position, lastCompany, applyForPosition;

    float experience, exp_salary;

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setLastCompany(String lastCompany) {
        this.lastCompany = lastCompany;
    }

    public void setApplyForPosition(String applyForPosition) {
        this.applyForPosition = applyForPosition;
    }

    public void setExperience(float experience) {
        this.experience = experience;
    }

    public void setExp_salary(float exp_salary) {
        this.exp_salary = exp_salary;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public String getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getAddress() {
        return address;
    }

    public String getQualification() {
        return qualification;
    }

    public String getPosition() {
        return position;
    }

    public String getLastCompany() {
        return lastCompany;
    }

    public String getApplyForPosition() {
        return applyForPosition;
    }

    public float getExperience() {
        return experience;
    }

    public float getExp_salary() {
        return exp_salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                ", emailId='" + emailId + '\'' +
                ", age='" + age + '\'' +
                ", gender='" + gender + '\'' +
                ", address='" + address + '\'' +
                ", qualification='" + qualification + '\'' +
                ", position='" + position + '\'' +
                ", lastCompany='" + lastCompany + '\'' +
                ", applyForPosition='" + applyForPosition + '\'' +
                ", experience=" + experience +
                ", exp_salary=" + exp_salary +
                '}';
    }
}
